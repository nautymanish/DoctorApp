﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DoctorApp.Controllers // it should be in model but due to time constraints this was creaed
{
    public class Doctor
    {
        public int Id { get; set; }
        [Required]
        public string Speciality { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public DateTime DOB { get; set; }
        [Required]
        public string Gender { get; set; }
        public string Image { get; set; }

        public string Note { get; set; }
        [Required]
        public bool Active { get; set; }
     }
}