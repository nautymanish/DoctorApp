﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoctorApp.Controllers
{
    public class HomeController : Controller
    {
        static List<Doctor> list;
        public HomeController() // we can use DI here to bring data from other layers
        {
           
                list = new List<Doctor>();
                list.Add(new Doctor() { FirstName = "First", LastName="Last", Active=true, DOB=Convert.ToDateTime("1-Jan-1990"), Gender="Male", Id=1, Image=string.Empty, Note=string.Empty, Speciality="Internal Medicine" });
                list.Add(new Doctor() { FirstName = "Second", LastName = "LastName", Active = true, DOB = Convert.ToDateTime("1-Jan-1980"), Gender = "Female", Id = 2, Image = string.Empty, Note = string.Empty, Speciality="Physician" });
           
        }
        public ActionResult Index()
        {
           
            return View();
        }
        public JsonResult GetDoctors()
        {
            
            return Json(list, JsonRequestBehavior.AllowGet);
        }

       public ActionResult AddDoctor(int DoctorID=0)
        {
            var doctorObject = new Doctor();
            if (DoctorID > 0)
            {
                doctorObject = list.Where(item => item.Id == DoctorID).Single();
            }
            return View(doctorObject);
        }
        [HttpPost]
        public ActionResult InsertDoctor(Doctor doctor)
        {
            var doc = list.Where(item => item.Id == doctor.Id);
            if (doc.Count()>0)
            {
                var item = doc.Single();
                item = doctor;
            }
            else
            list.Add(doctor);
            return RedirectToAction("Index");
        }
    }
}